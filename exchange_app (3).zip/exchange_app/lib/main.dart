import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Para Birimi Çevirici'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String apiResponse ="";
  String? baseCurrency;
  String? convertTo;
  final amountController = TextEditingController();


  Future<void> fetchCurrency(String base, String to, num amount) async {
    String apiKey = "s2o7lv3de0gh2diel8774g9tnssjk99ugnb539ujtfg8cae0qbjj3b";
    final response = await http.get(Uri.parse(
        'https://anyapi.io/api/v1/exchange/convert?base=$base&to=$to&amount=$amount&apiKey=$apiKey'));
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      apiResponse = response.body;
      setState(() {

      });
    } else {
      apiResponse = "Bağlantı Başarısız";
      throw Exception('Failed to load album');
      setState(() {
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SizedBox(
        child: Wrap(
          spacing: 15.0,
          children: [
            SizedBox(
              child: Column(
                children: [
                  DropdownButton<String>(
                      items: const [
                        DropdownMenuItem(
                          value: "TRY",
                          child: Text("TRY"),
                        ),
                        DropdownMenuItem(
                          value: "USD",
                          child: Text("USD"),
                        ),
                        DropdownMenuItem(
                          value: "EUR",
                          child: Text("EUR"),
                        )
                      ],
                      hint: const Text("Baz alınacak para birimi :"),
                      value: baseCurrency,
                      onChanged: (String? value) {
                        setState(() {
                          baseCurrency = value ?? "";
                        });
                      }),
                ],
              ),
            ),

            SizedBox(
                child: Column(
                  children: [
                    DropdownButton<String>(
                        items: const [
                          DropdownMenuItem(
                            value: "TRY",
                            child: Text("TRY"),
                          ),
                          DropdownMenuItem(
                            value: "USD",
                            child: Text("USD"),
                          ),
                          DropdownMenuItem(
                            value: "EUR",
                            child: Text("EUR"),
                          )
                        ],
                        hint: const Text(
                            "Çevrilmesini istediğiniz para birimini seçiniz:"),
                        value: convertTo,
                        onChanged: (String? value) {
                          setState(() {
                            convertTo = value ?? "";
                          });
                        })
                  ],
                )),

            SizedBox(
              width: 150,
              child: Column(
                children:  [
                  TextField(
                    controller: amountController,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      FilteringTextInputFormatter.digitsOnly
                    ],
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 40.0),
                      border: OutlineInputBorder(),
                      labelText: "Adet: ",
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(
              child: Row(
                children: [
                  CupertinoButton(color: Colors.amberAccent, onPressed:() => {
                    fetchCurrency(baseCurrency!, convertTo!, num.parse(amountController.text)),
                  }, child: const Text("Değeri Getir")),
                ],
              ),
            ),
            SizedBox(
              child: Row(
                children: <Widget>[
                  Text(apiResponse,),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}